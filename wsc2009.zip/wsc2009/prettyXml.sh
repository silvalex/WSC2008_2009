#!/bin/tcsh
foreach x (`ls *.xml`)
  xmllint --format $x >! tmp.xml
  cat tmp.xml >! $x
  rm tmp.xml
end
